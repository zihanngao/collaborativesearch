﻿namespace Contoso.NoteTaker.JSON.Format
{
    public class InkParagraph : InkRecognitionUnit
    {
    }
}
