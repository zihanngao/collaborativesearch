﻿namespace Contoso.NoteTaker.JSON.Format
{
    public class InkWritingRegion : InkRecognitionUnit
    {
    }
}
