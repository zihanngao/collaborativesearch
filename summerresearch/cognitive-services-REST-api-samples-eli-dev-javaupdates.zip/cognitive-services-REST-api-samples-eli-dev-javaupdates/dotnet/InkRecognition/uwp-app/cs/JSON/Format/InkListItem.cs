﻿namespace Contoso.NoteTaker.JSON.Format
{
    public class InkListItem : InkRecognitionUnit
    {
    }
}
