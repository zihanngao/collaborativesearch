
import Foundation

@objc
class InkListItem : InkRecognitionUnit {
    
    @objc
    override init(json : [String: Any]) {
        super.init(json:json)
    }
}
