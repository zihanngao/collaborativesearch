

import Foundation
@objc
class InkWritingRegion : InkRecognitionUnit {
    
    @objc
    override init(json : [String: Any]) {
        super.init(json:json)
    }
}
