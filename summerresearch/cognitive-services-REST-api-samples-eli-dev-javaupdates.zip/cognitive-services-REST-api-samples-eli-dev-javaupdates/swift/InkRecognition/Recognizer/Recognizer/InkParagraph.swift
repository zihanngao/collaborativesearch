
import Foundation

@objc
class InkParagraph : InkRecognitionUnit {
    
    @objc
    override init(json : [String: Any]) {
        super.init(json:json)
    }
}
