package CognitiveServices.Ink.Recognition;

public enum RecognitionResultStatus {
    UNCHANGED,
    UPDATED,
    FAILED
}
