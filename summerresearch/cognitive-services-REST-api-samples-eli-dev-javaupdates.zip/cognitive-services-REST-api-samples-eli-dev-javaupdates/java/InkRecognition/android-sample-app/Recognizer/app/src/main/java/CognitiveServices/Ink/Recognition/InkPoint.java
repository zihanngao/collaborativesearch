package CognitiveServices.Ink.Recognition;

public class InkPoint {
    final float x;
    final float y;

    InkPoint(float x, float y) {
        this.y = y;
        this.x = x;
    }
}
