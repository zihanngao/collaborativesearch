package CognitiveServices.Ink.Recognition;

public enum StrokeKind {
    DRAWING,
    WRITING,
    UNKNOWN,
}
